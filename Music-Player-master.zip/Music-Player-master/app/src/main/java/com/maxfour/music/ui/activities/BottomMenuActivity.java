package com.maxfour.music.ui.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.maxfour.music.R;
import com.maxfour.music.databinding.ActivityBottomMenuBinding;
import com.maxfour.music.ui.activities.base.AbsSlidingMusicPanelActivity;
import com.maxfour.music.ui.fragments.mainactivity.library.LibraryFragment;
import com.maxfour.music.util.PreferenceUtil;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BottomMenuActivity extends AbsSlidingMusicPanelActivity {
    //ActivityBottomMenuBinding mBinding;


    @Nullable
    MainActivityFragmentCallbacks currentFragment;


    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDrawUnderStatusbar();
        ButterKnife.bind(this);


        init();
    }

    @Override
    protected View createContentView() {

        View contentView = getLayoutInflater().inflate(R.layout.activity_main_drawer_layout, null);
        ViewGroup drawerContent = contentView.findViewById(R.id.drawer_content_container);
        drawerContent.addView(wrapSlidingMusicPanel(R.layout.activity_bottom_menu));
        return contentView;
    }

    private void init() {
        setCurrentFragment(LibraryFragment.newInstance());

        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        //mBinding.navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }

    private void setCurrentFragment(@SuppressWarnings("NullableProblems") Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment, null).commit();
        currentFragment = (MainActivityFragmentCallbacks) fragment;
    }
    private void restoreCurrentFragment() {
        currentFragment = (MainActivityFragmentCallbacks) getSupportFragmentManager().findFragmentById(R.id.frame_layout);
    }
    private void setUpDrawerLayout() {
        //setUpNavigationView();
    }




    private void changeFragmentView(Fragment selectedFragment) {
        clearBackStack();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout, selectedFragment);
        transaction.commit();
    }

    private void clearBackStack() {
        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            FragmentManager.BackStackEntry first = manager.getBackStackEntryAt(0);
            manager.popBackStack(first.getId(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
    }


    public interface MainActivityFragmentCallbacks {
        boolean handleBackPress();
    }

}
