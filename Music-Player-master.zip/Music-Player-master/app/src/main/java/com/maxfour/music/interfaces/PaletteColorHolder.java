package com.maxfour.music.interfaces;

import androidx.annotation.ColorInt;

public interface PaletteColorHolder {

    @ColorInt
    int getPaletteColor();
}
