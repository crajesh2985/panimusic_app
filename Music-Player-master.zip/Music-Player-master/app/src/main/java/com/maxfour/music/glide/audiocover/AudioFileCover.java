package com.maxfour.music.glide.audiocover;

public class AudioFileCover {
    public final String filePath;

    public AudioFileCover(String filePath) {
        this.filePath = filePath;
    }
}
