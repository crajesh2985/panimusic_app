package sg.edu.tp.musicstream.model.smartplaylist;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import sg.edu.tp.musicstream.R;
import sg.edu.tp.musicstream.loader.TopAndRecentlyPlayedSongsLoader;
import sg.edu.tp.musicstream.model.Song;
import sg.edu.tp.musicstream.provider.SongPlayCountStore;

import java.util.List;

public class MyTopSongsPlaylist extends AbsSmartPlaylist {

    public MyTopSongsPlaylist(@NonNull Context context) {
        super(context.getString(R.string.my_top_songs), R.drawable.ic_trending_up_white_24dp);
    }

    @NonNull
    @Override
    public List<Song> getSongs(@NonNull Context context) {
        return TopAndRecentlyPlayedSongsLoader.getTopSongs(context);
    }

    @Override
    public void clear(@NonNull Context context) {
        SongPlayCountStore.getInstance(context).clear();
    }


    @Override
    public int describeContents() {
        return 0;
    }

    protected MyTopSongsPlaylist(Parcel in) {
        super(in);
    }

    public static final Parcelable.Creator<MyTopSongsPlaylist> CREATOR = new Parcelable.Creator<MyTopSongsPlaylist>() {
        public MyTopSongsPlaylist createFromParcel(Parcel source) {
            return new MyTopSongsPlaylist(source);
        }

        public MyTopSongsPlaylist[] newArray(int size) {
            return new MyTopSongsPlaylist[size];
        }
    };
}