package sg.edu.tp.musicstream.glide;

import android.content.Context;

import java.io.InputStream;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.module.GlideModule;
import sg.edu.tp.musicstream.glide.artistimage.ArtistImage;
import sg.edu.tp.musicstream.glide.artistimage.ArtistImageLoader;
import sg.edu.tp.musicstream.glide.audiocover.AudioFileCover;
import sg.edu.tp.musicstream.glide.audiocover.AudioFileCoverLoader;

public class MusicGlideModule implements GlideModule {

  	@Override
  	public void applyOptions(Context context, GlideBuilder builder) {
    }

    @Override
    public void registerComponents(Context context, Glide glide) {
        glide.register(AudioFileCover.class, InputStream.class, new AudioFileCoverLoader.Factory());
        glide.register(ArtistImage.class, InputStream.class, new ArtistImageLoader.Factory());
    }
}
