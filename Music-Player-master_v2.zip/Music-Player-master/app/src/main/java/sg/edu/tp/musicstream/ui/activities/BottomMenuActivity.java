package sg.edu.tp.musicstream.ui.activities;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import sg.edu.tp.musicstream.R;

import sg.edu.tp.musicstream.ui.activities.base.AbsSlidingMusicPanelActivity;
import sg.edu.tp.musicstream.ui.fragments.mainactivity.library.LibraryFragment;

import androidx.annotation.Nullable;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BottomMenuActivity extends AbsSlidingMusicPanelActivity {
    //ActivityBottomMenuBinding mBinding;


    @Nullable
    MainActivityFragmentCallbacks currentFragment;


    @BindView(R.id.drawer_layout)
    DrawerLayout drawerLayout;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setDrawUnderStatusbar();
        ButterKnife.bind(this);


        init();
    }

    @Override
    protected View createContentView() {

        View contentView = getLayoutInflater().inflate(R.layout.activity_main_drawer_layout, null);
        ViewGroup drawerContent = contentView.findViewById(R.id.drawer_content_container);
        drawerContent.addView(wrapSlidingMusicPanel(R.layout.activity_bottom_menu));
        return contentView;
    }

    private void init() {
        setCurrentFragment(LibraryFragment.newInstance());

        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        //mBinding.navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }

    private void setCurrentFragment(@SuppressWarnings("NullableProblems") Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment, null).commit();
        currentFragment = (MainActivityFragmentCallbacks) fragment;
    }
    private void restoreCurrentFragment() {
        currentFragment = (MainActivityFragmentCallbacks) getSupportFragmentManager().findFragmentById(R.id.frame_layout);
    }
    private void setUpDrawerLayout() {
        //setUpNavigationView();
    }




    private void changeFragmentView(Fragment selectedFragment) {
        clearBackStack();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout, selectedFragment);
        transaction.commit();
    }

    private void clearBackStack() {
        FragmentManager manager = getSupportFragmentManager();
        if (manager.getBackStackEntryCount() > 0) {
            FragmentManager.BackStackEntry first = manager.getBackStackEntryAt(0);
            manager.popBackStack(first.getId(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
    }


    public interface MainActivityFragmentCallbacks {
        boolean handleBackPress();
    }

}
