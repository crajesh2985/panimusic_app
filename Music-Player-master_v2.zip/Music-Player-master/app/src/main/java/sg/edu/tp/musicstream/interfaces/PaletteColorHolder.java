package sg.edu.tp.musicstream.interfaces;

import androidx.annotation.ColorInt;

public interface PaletteColorHolder {

    @ColorInt
    int getPaletteColor();
}
