package sg.edu.tp.musicstream.ui.fragments.mainactivity;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import sg.edu.tp.musicstream.ui.activities.BottomMenuActivity;

public abstract class AbsMainActivityFragment extends Fragment {

    public BottomMenuActivity getMainActivity() {
        return (BottomMenuActivity) getActivity();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setHasOptionsMenu(true);
    }
}
